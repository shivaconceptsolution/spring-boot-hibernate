package scs.welcomespring;

import org.springframework.boot.SpringApplication;

public class SpringBootMain {

	public static void main(String[] args) {
	SpringApplication.run(SIController.class,args);	

	}

}
